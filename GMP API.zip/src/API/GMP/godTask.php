<?php
namespace API\GMP;

use pocketmine\scheduler\Task;

class godTask extends Task
{
	private $main;
	private $target;

	public function __construct($main, $target) {
		$this->plugin = $main;
		$this->player = $target;
	}
	public function onRun():void {
		$cs = $this->player;
		$cs->setHealth($cs->getMaxHealth());
		$this->shutdown();
	}
}