<?php
namespace API\GMP\commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use pocketmine\Server;

use API\GMP\godTask;

use function in_array;
//use function unset;
use function array_search;

class CommandGod extends Command
{
	private $plugin;

	public $god = [];

	function __construct(string $name, string $description, string $usageMessage, $plugin)
	{
		parent::__construct($name, $description, $usageMessage);
		$this->API = $plugin;
	}
	public function execute(CommandSender $cs, string $commandLabel, array $args): bool {
		$cs_name = $cs->getName();
		if (!$cs instanceof Player) return false;
		if (!in_array($cs_name, $this->god)) {
			$this->god[$cs_name] = true;
			$cs->setFlying(true);
			$cs->setAllowFlight(true);
			$cs->setHealth($cs->getMaxHealth());
//			$this->task = $this->API->getScheduler()->scheduleRepeatingTask(new godTask($this, $cs), 10);
			$cs->sendMessage("you in god");
			return true;
		} elseif (in_array($cs_name, $this->god)) {
			unset($this->god[array_search($cs_name, $this->god)]);
			if ($cs->isCreative()) {
//				$this->task->shutdown();
				$cs->setFlying(false);
				$cs->sendMessage("you exit god");
				return true;
			}
			$cs->sendMessage("you exit god");
			$cs->setFlying(false);
			$cs->setAllowFlight(false);
			return true;
		}
		$cs->sendMessage("error");
		return false;
	}
}