<?php
namespace API\GMP\commands;

use pocketmine\player\Player;
use pocketmine\scheduler\Task;
use pocketmine\event\Listener;
use pocketmine\Server;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\permission\DefaultPermissions;

class CMD extends Task
{

	private $plugin;

	public function __construct($plugin) {
		$this->main = $plugin;
	}
	public function onRun():void {
//		$this->plugin->getServer()->getCommandMap()->register("")
		$this->main->getServer()->getCommandMap()->register("", new CommandGetIP("getip", "getip <player>", "", $this->main));
		$this->main->getServer()->getCommandMap()->register("", new CommandGMPTest("gmptest", "gmptest", "", $this->main));
		$this->main->getServer()->getCommandMap()->register("", new Commandsayall("sayall", "sayall <text>", "", $this->main));
//		$this->main->getServer()->getCommandMap()->register("", new Commandwebhook("webhook", "webhook <text>", "", $this->main));
		$this->main->getServer()->getCommandMap()->register("", new CommandGod("god", "god", "", $this->main));
	}
}