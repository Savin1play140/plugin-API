<?php
namespace API\GMP\commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use pocketmine\Server;

use API\GMP\discord\Embed;
use API\GMP\discord\Message;
use API\GMP\discord\Webhook;

class Commandwebhook extends Command {
	private $plugin;
	function __construct(string $name, string $description, string $usageMessage, $plugin)
	{
		parent::__construct($name, $description, $usageMessage);
		$this->API = $plugin;
	}
	public function execute(CommandSender $cs, string $commandLabel, array $args): bool {
		if (!isset($args[0])) {
			return false;
		}
		$text = $args[0];
		$webhookurl = "https://discord.com/api/webhooks/988843972229222440/pmEAiywVaHnuJGNfe-iF8v9FhJHeaOiK-6IZO-SPPCJXWYo759qTY7fe6UYnGGdC9bXr";
		$webhook = new Webhook($webhookurl);
		$embed = new Embed();
		$msg = new Message();
		$embed->setTitle("Репорт");
		$embed->setDescription($text);
		$embed->setFooter(date("d.m.Y"));
		$embed->setColor("15548997");
		$msg->addEmbed($embed);
		$webhook->send($msg);
		return true;
	}
}