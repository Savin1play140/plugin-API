<?php
namespace API\GMP\commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use pocketmine\Server;

class CommandDamage extends Command
{
	private $plugin;
	function __construct(string $name, string $description, string $usageMessage, $plugin)
	{
		parent::__construct($name, $description, $usageMessage);
		$this->API = $plugin;
	}
	public function execute(CommandSender $cs, string $commandLabel, array $args):bool {
		if (!isset($args[0])) {
			$cs->sendMessage("usage: /damage <int|count> <player>");
			return false;
		}
		if (!isset($args[1])) {
			$count = $args[0];
			$cs->setHealth($cs->getHealth() - $count);
			return true;
		}
		if (Server::getInstance()->getPlayerExact($args[1]) === null) {
			$cs->sendMessage("player it's not online!");
			return false;
		};
		$player = Server::getInstance()->getPlayerExact($args[1]);
		$count = $args[0];
		$player->setHealth($player->getHealth() - $count);
		return true;
	}
}