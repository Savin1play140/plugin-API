<?php
namespace API\GMP;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use pocketmine\Server;

class CommandFunction extends Command {
	private $plugin;
	function __construct(string $name, string $description, string $usageMessage, $plugin)
	{
		parent::__construct($name, $description, $usageMessage);
		$this->API = $plugin;
	}
	public function execute(CommandSender $cs, string $commandLabel, array $args): bool {
		switch ($args[0] ?? "function") {
			default:
				$cs->sendMessage("execute: \n sayall <text> for say all here and \n getip <player> for get player ip");
				return false;
				break;
		}
	}
}
?>