<?php
namespace API\GMP\commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use pocketmine\Server;

class CommandGMPTest extends Command
{
	private $plugin;
	function __construct(string $name, string $description, string $usageMessage, $plugin)
	{
		parent::__construct($name, $description, $usageMessage);
		$this->API = $plugin;
	}
	public function execute(CommandSender $cs, string $commandLabel, array $args): bool {
		if ($this->API->GMPTest() == true) {
			$cs->sendMessage("GMP here!");
			return true;
		} else {
			$cs->sendMessage("GMP not here!");
			return false;
		}
	}
}