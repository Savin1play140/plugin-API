<?php
namespace API\GMP\commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use pocketmine\Server;

class Commandsayall extends Command
{
	private $plugin;
	function __construct(string $name, string $description, string $usageMessage, $plugin)
	{
		parent::__construct($name, $description, $usageMessage);
		$this->API = $plugin;
	}
	public function execute(CommandSender $cs, string $commandLabel, array $args): bool {
		$name = $cs->getName();
		if (!isset($args[0])) {
			$cs->sendMessage("use /sayall <text>");
			return false;
		}
		$this->API->SayAllPlayers($args);
		$cs->sendMessage("successfully sending message");//успешная отправка сообщения
		Server::getInstance()->getLogger()->warning("successfully sending players message by $name");//успешно отправил игрокам здесь сообщение
		return true;
	}
}