<?php
namespace API\GMP\commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use pocketmine\Server;

class CommandGetIP extends Command
{
	private $plugin;
	function __construct(string $name, string $description, string $usageMessage, $plugin)
	{
		parent::__construct($name, $description, $usageMessage);
		$this->API = $plugin;
	}
	public function execute(CommandSender $cs, string $commandLabel, array $args): bool {
		if (!isset($args[0])) {
			$cs->sendMessage("use /function getip <player>");
			return false;
		}
		if ($this->API->PlayerISOnline($args[0]) != true) {
			$cs->sendMessage("player not found");
			return false;
		}
		$cs->sendMessage($this->API->getPlayerIP($args[0]));
		return true;
	}
}