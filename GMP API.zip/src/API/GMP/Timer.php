<?php

namespace API\GMP;

use pocketmine\scheduler\Task;

class Timer extends Task{

	private $main;
	public $text;

	public function __construct($main, $txt) {
		$this->api = $main;
		$this->text = $txt;
	}

	public function onRun():void {
		$this->api->SayAllPlayers($this->api->timer($this->text));
	}
}
?>