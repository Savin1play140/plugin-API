<?php
namespace API\GMP;
// BASE / БАЗА
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\Server;
// EVENTS / СОБЫТИЯ
use pocketmine\network\protocol\EventPacket;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerChatEvent;
// COMMANDS / КОМАНДЫ
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
// 2d and 3d / 2d а также 3d
use pocketmine\world\Position;
use pocketmine\math\Vector3;
use pocketmine\math\Vector2;
//other
use pocketmine\network\mcpe\protocol\types\DeviceOS;
use pocketmine\utils\Config;

use API\GMP\discord\Embed;
use API\GMP\discord\Message;
use API\GMP\discord\Webhook;

use API\GMP\commands\CMD;
use API\GMP\commands\CommandGMPTest;
use API\GMP\commands\CommandGetIP;
use API\GMP\commands\Commandsayall;
use API\GMP\commands\CommandGod;
use API\GMP\commands\CommandDamage;

final class API extends PluginBase implements Listener
{
	public $config;
	public $msg;
	public $eco;

	const PREFIX = "SimpleAPI";

	public $god = [];

	public function addTimesetGift(int $sec) {
		return $this->timesetItem = time() + $sec;
	}
	public function SayAllPlayers($text) {
		if ($text != "" or $text != " ") {
			foreach($this->getServer()->getOnlinePlayers() as $players) {
				$player_name = $players->getName();
				$players->sendMessage(str_replace("{name}", $player_name, $text));
			}
		} else {
			foreach($this->getServer()->getOnlinePlayers() as $players) {
				$this->getLogger()->error("text = \" \" or text = null");
			}
		}
		return $text;
	}
	public function sendMessageRepeating(int $value, $text) {
		$this->getScheduler()->scheduleRepeatingTask(new Timer($this, $text), 20*$value);
	}
	public function sendWebHook(string $webhook, $nick, $txt) {
		$webhook = new Webhook($webhook);
		$embed = new Embed();
		$msg = new Message();
		$embed->setTitle($nick);
		$embed->setDescription($txt);
		$embed->setFooter(date("d.m.Y"));
		$embed->setColor("15548997");
		$msg->addEmbed($embed);
		$webhook->send($msg);
	}

	public static function TRUEReturn() {
		return true;
	}
	public static function NullReturn() {
		return null;
	}
	public static function FALSEReturn() {
		return false;
	}

	public function getDeviceOS($player) {
		$DATA = $player->getPlayerInfo()->getExtraData();

		return match ($DATA["DeviceOS"]) {
			DeviceOS::ANDROID => "§2android",// 0, top
			DeviceOS::WINDOWS_10 => "§9win 10",//1
			DeviceOS::WIN32 => "§3win 7 edu",//2
			DeviceOS::XBOX => "§0xbox",//3
			DeviceOS::PLAYSTATION => "§fPlayStation",//4
			DeviceOS::NINTENDO => "§cNin§bTendo",//5
			DeviceOS::TVOS => "TY OS",//6
			DeviceOS::AMAZON => "§cFire§fOS",//7
			DeviceOS::WINDOWS_PHONE => "§9win phone",//8
			DeviceOS::GEAR_VR => "§fVR",//9
			DeviceOS::HOLOLENS => "HoloLens",//10
			DeviceOS::DEDICATED => "DediCated",//11
			DeviceOS::OSX => "§fMacOS",//12
			DeviceOS::IOS => "§fIOS",//13
			default => "UNKNOWN"//-1
		};
	}
	public function info($name, $description, $YouTube, $type) {
		$text = "plugin: $name, description: \n$description.\nYouTube channel: $YouTube.";
		if ($type == "Logger") {
			$this->getLogger()->notice("$text");
		} elseif (Server::getInstance()->getPlayerExact($type)) {
			$output = Server::getInstance()->getPlayerExact($type);
			$output->sendMessage("$text");
		} elseif (!Server::getInstance()->getPlayerExact($type) && !$type == "Logger") {
			$this->getLogger()->error("Unknown output type: $type");
		}
	}
	public function queryPlayer($player, string $query, $answer) {
		if (Server::getInstance()->getPlayerExact($player) !== null) {
			$player = Server::getInstance()->getPlayerExact($player);
			$event = new PlayerChatEvent($player);
			$player->sendMessage("$query");
			if ($event->getMessage() === "$answer") {
				return true;
			} else {
				return false;
			}
		} else {
			$this->getLogger()->critical("not found player");
			return null;
		}
	}
	public function getPlayerIP($player) {
		$IP = Server::getInstance()->getPlayerExact($player)->getNetworkSession()->getIp();
		return $IP;
	}
	public function setIP($player, $ip) {
		if (Server::getInstance()->getPlayerExact($player) === null) {
			return false;
		} elseif (!Server::getInstance()->getPlayerExact($player) === null) {
			$player_name = $player->getName();
			$this->config->set($player_name, $ip);
			return true;
		}
	}

	public function PlayerISOnline($player) {
		if (Server::getInstance()->getPlayerExact($player) == null) {
			return false;
		}
		$player = Server::getInstance()->getPlayerExact($player);
		return $player;
	}

	public function Mystery(bool $bool) {
		$mystery = "☝💣🏱📂🗐";
		if ($bool == true) {
			Server::getInstance()->getLogger()->notice($mystery);
			$this->SayAllPlayers($mystery);
		}
		Server::getInstance()->getLogger()->notice("Mystery no!");
	}

	public function timer($text) {
		$this->msg = array(
			$this->config->getNested("texts.text1"),
			$this->config->getNested("texts.text2"),
			$this->config->getNested("texts.text3"),
			$this->config->getNested("texts.text4"),
			$this->config->getNested("texts.text5"),
			"$text"
		);
		$txt = "§l§6".$this->msg[mt_rand(0,5)];
		return $txt;
	}

	public function setGod(Player $player):void {
		if (Server::getInstance()->getPlayerExact("$player") !== null) {
			$player_name = $player->geName();
			$player->setFlying(true);
			$player->setFly(true);
			$player->setHealth($player->getMaxHealth());
			$this->god[] = $player_name;
		} else {
			return;
		}
	}
	public function unsetGod(Player $player) {
		if (Server::getInstance()->getPlayerExact("$player") !== null) {
			$player_name = $player->getName();
			$player->setFlying(false);
			$player->setFly(false);
			unset($this->god[$player_name]);
		} else {
			return;
		}
	}
	public function getGod():bool {
		return $this->god;
	}
	public function year(int $year, ?int $day, ?int $month) {
		$nowYear = date('Y');
		$nowMonth = date('m');
		$nowDay = date('d');
		$next = $nowYear+1;
		$year = $nowYear-$year;
		if ($nowDay == $day and $nowMonth == $month) {
			$txt2 = "new progect year, now year: $year";
			return $txt2;
		} else {
			$txt = "now progect year: $year, next progect year: $next.$month.$day";
			return $txt;
		}
	}
	public function GMPTest() {
		$test = Server::getInstance()->getPlayerExact("Savin play14");
		if ($test == null) {
			return false;
		} else {
			return true;
		}
	}
	public function AddBalance(int $int, $player) {
		$player_name = Server::getInstance()->getPlayerExact($player);
		$int = $this->eco->get($player_name) + $int;
		$this->eco->set($player_name, $int);
	}
	public function removeBalance(int $int, $player) {
		$player_name = Server::getInstance()->getPlayerExact($player);
		$int = $this->eco->get($player_name) - $int;
		$this->eco->set($player_name, $int);
	}
	public function setBalance(int $int, $player) {
		$player_name = Server::getInstance()->getPlayerExact($player)->getName();
		$this->eco->set($player_name, $int);
	}
	public function getBalance($player) {
		$balance = $this->eco->get($player_name);
		return $balance;
	}
	public function gen_password($length = 6)
	{
		$chars = "012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789";
		return substr(str_shuffle($chars), 0, $length);
	}
	public function gen_nick($length = 6)
	{
		$chars = "QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm";
		return substr(str_shuffle($chars), 0, $length);
	}
	public function onEnable(): void {
		if (!is_file($this->getDataFolder()."texts.yml")) {
			$this->saveResource("texts.yml");
		}
		$this->config = new Config($this->getDataFolder()."texts.yml", Config::YAML);
		$this->eco = new Config($this->getDataFolder()."economy.json", Config::JSON);
		$this->getLogger()->notice("plugin class: \"".__CLASS__."\"!");
//		$this->getLogger()->notice();

		$this->getServer()->getCommandMap()->register("", new CommandGetIP("getip", "getip <player>", "", $this));
		$this->getServer()->getCommandMap()->register("", new CommandGMPTest("gmptest", "gmptest", "", $this));
		$this->getServer()->getCommandMap()->register("", new Commandsayall("sayall", "sayall <text>", "", $this));
		$this->getServer()->getCommandMap()->register("", new CommandDamage("damage", "damage <int|count> <player>", "", $this));
		$this->getServer()->getCommandMap()->register("", new CommandGod("god", "god", "", $this));

	}
	public function onDisable(): void {}
	public function onPlayer(PlayerJoinEvent $event2, PlayerChatEvent $event) {
		$player = $event->getPlayer();
		$player_name = $player->getName();
		$player->sendMessage("you love game?");
		if ($event->getMessage() == "yes") {
			$player->sendMessage("great!");
		} elseif ($event->getMessage() == "no") {
			$player->sendMessage("why?");
		}
	}
}
?>